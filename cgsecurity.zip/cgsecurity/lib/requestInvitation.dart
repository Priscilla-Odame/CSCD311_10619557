//Basic Flutter import(s)
import 'package:flutter/material.dart';
import 'user.dart';
import 'dart:io';

//image_picker import(s)
import 'package:image_picker/image_picker.dart';

//LoginPage import(s)
import 'LoginPage.dart';


class RequestInvitationPage extends StatefulWidget {

  @override
  _MyRequestInvitationPageState createState() => new _MyRequestInvitationPageState();

}

class _MyRequestInvitationPageState extends State<RequestInvitationPage> {

  bool users = false;
  var reviews;
  String sp_user_uid, sp_username;

  bool isLoggedIn = false;
  String _occupation;
  String _rationale;

  //Initializing FormKey

  final _inviteFormKey = new GlobalKey<FormState>();

  //Initializing ProgressDialog

  //ProgressDialog pr;

  //Fire base signout function Starts Here

//  Future <void> _signOut()  async {
//    return FirebaseAuth.instance.signOut();
//
//  }

  //Fire base signout function Ends Here


  //Function to validate From

  bool validateAndSave() {
    final signUpForm = _inviteFormKey.currentState;
    if (signUpForm.validate()) {
      signUpForm.save();
      return true;
    }
    else {
      return false;
    }

  }

  @override
  void initState() {
    super.initState();

    //Check if "CurrentUser" is null

//    FirebaseAuth.instance.currentUser().then((user) => user != null ? setState(() {
//      isLoggedIn = true;
//      getValuesSF();
//
//    })

    //Push User to Login Page when "CurrentUser" is Empty

       // : Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage())));

    // new Future.delayed(const Duration(seconds: 2));

  }


  //Get SharedPreferences value from user after Login Starts Here

//  getValuesSF() async {
//    SharedPreferences prefs = await SharedPreferences.getInstance();
//    //Return String
//    sp_user_uid = prefs.getString('sp_user_uid');
//    sp_username = prefs.getString('sp_username');
//    print(sp_user_uid);
//  }

  //Get SharedPreferences value from user after Login Ends Here


  //Post invite method Starts Here

//  postInvite() async {
//
//    pr = new ProgressDialog(context,ProgressDialogType.Normal);
//
//    if (validateAndSave()) { //Check if Form is validated
//      try {
//
//        pr.show(); //The loader that shows when a request is being made
//
//        checkInvites().getUser(sp_user_uid)
//            .then((QuerySnapshot docs) {
//
//          if (docs.documents.isNotEmpty) {
//
//            pr.hide(); //Hiding loader after request has been made
//            _duplicateInvite(); //Calling "Duplicate Invite" Dialog
//
//          }
//          else {
//
//            postInviteNow() async {
//              FirebaseUser user = await FirebaseAuth.instance.currentUser();
//              Firestore.instance.collection('invites').document().setData(
//                  {
//                    //Adding "uid" to user table
//                    'uid': user.uid,
//                    //Adding "email" to user table
//                    'email': user.email,
//                    //Adding "displayName" to user table
//                    'name': user.displayName,
//                    //Adding "occupation" to user table
//                    'occupation': _occupation,
//                    //Adding "rationale" to user table
//                    'rationale': _rationale,
//                  });
//            }
//            postInviteNow(); //Calling "Duplicate Invite" Method
//            _inviteSent(); //Calling "Invite Sent" Dialog
//            pr.hide(); //Hiding loader after request has been made
//
//          }
//        });
//      } catch (e) {
//        print(e);
//      }
//    }
//
//  }

  //Post invite method Starts Here


  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.orange,
        title: Text("Firebase SetUp"),
      ),
      body: new Container(
        decoration: new BoxDecoration(color: Colors.white),
        padding: EdgeInsets.all(16.0),
        child: new Form(
            key: _inviteFormKey,
            child: new ListView(
              //crossAxisAlignment: CrossAxisAlignment.stretch,
              //mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                new FlightImageAsset(
                ),
                //SizedBox(height: 50.0),
                sp_username == null
                    ? new Text('')
                    : new Center(
                    child: Text('$sp_username',
                      style: TextStyle(color: Colors.grey, fontSize: 25),)),
                SizedBox(height: 20.0),
                new Text('Fill the Form below to request invitation at DDW',
                  style: TextStyle(color: Colors.grey, fontSize: 21),),
                SizedBox(height: 20.0),
                new TextFormField(
                  decoration: new InputDecoration(labelText: 'Occupation', icon: new Icon(Icons.business, color: Colors.grey,)),
                  validator: (value) => value.isEmpty ? 'Occupation is Required' : null,
                  onSaved: (value) => _occupation = value,
                ),
                new TextFormField(
                  maxLines: null,
                  keyboardType: TextInputType.multiline,
                  decoration: new InputDecoration(labelText: "Rationale", icon: new Icon(Icons.message, color: Colors.grey,)),
                  validator: (value) => value.isEmpty ? 'Rationale is Required' : null,
                  onSaved: (value) => _rationale = value,
                ),
                SizedBox(height: 20.0),
                new RaisedButton(
                    child: new Text("Request Invite", style: new TextStyle(fontSize: 20.0, color: Colors.white),),
                    color: Colors.orange,
                    elevation: 4.0,
                    onPressed: (){
                      //postInvite(); //Calling postInvite button onpress of Request Invite button
                    }
                ),
              ],
            )),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          //_signOut();
          Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()));
        },
        child: Icon(Icons.exit_to_app, color: Colors.white,),
        backgroundColor: Colors.orange,
      ),);
  }

  //Alert Dialog starts here

  //Alert Dialog for "Duplicate Invite" Starts Here

//  Future<void> _duplicateInvite() async {
//    return showDialog<void>(
//      context: context,
//      barrierDismissible: false, // user must tap button!
//      builder: (BuildContext context) {
//        return AlertDialog(
//          title: Text('Duplicate Invite'),
//          content: Text(
//              'You have already sent an Invite.'),
//          actions: <Widget>[
//            FlatButton(
//              child: Text('Dismiss'),
//              onPressed: () {
//                Navigator.of(context).pop();
//              },
//            ),
//          ],
//        );
//      },
//    );
//  }

 //Alert Dialog for "Duplicate Invite" Ends Here


  //Alert Dialog for "Invitation Sent Successfully" Starts Here

//  Future<void> _inviteSent() async {
//    return showDialog<void>(
//      context: context,
//      barrierDismissible: false, // user must tap button!
//      builder: (BuildContext context) {
//        return AlertDialog(
//          title: Text('Invitation Sent Successfully'),
//          content: Text(
//              'You have Successfully sent your Invite.'),
//          actions: <Widget>[
//            FlatButton(
//              child: Text('Dismiss'),
//              onPressed: () {
//                Navigator.of(context).pop();
//              },
//            ),
//          ],
//        );
//      },
//    );
//  }

//Alert Dialog for "Invitation Sent Successfully" Starts Here


//Alert Dialog Ends here


}


//Profile Image of User

class FlightImageAsset extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => _MyAppImage()),
        );
      },
      child: CircleAvatar(
        radius: 170.0,
        backgroundImage: NetworkImage('https://picsum.photos/250?image=9'),
        backgroundColor: Colors.transparent,
      ),
    );

  }

}


////////////////////////////////////////////////////////////////////////////////
/////////////////   Updating the Profile Image of Users    /////////////////////
////////////////////////////////////////////////////////////////////////////////



class _MyAppImage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new UserOptions(),
    );
  }

}

class UserOptions extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new UserOptionsState();
  }
}

class UserOptionsState extends State<UserOptions> {

  //save the result of gallery file
  File galleryFile;

  //save the result of camera file
  File cameraFile;

  //Initializing ProgressDialog

  //ProgressDialog prMyapp;

  //display image selected from gallery Starts Here

  imageSelectorGallery() async {
    galleryFile = await ImagePicker.pickImage(
      source: ImageSource.gallery,
      // maxHeight: 50.0,
      // maxWidth: 50.0,
    );
    print("You selected gallery image : " + galleryFile.path);
    setState(() {});
  }

  //display image selected from gallery Ends Here


  //display image selected from camera Starts Here
  imageSelectorCamera() async {
    cameraFile = await ImagePicker.pickImage(
      source: ImageSource.camera,
      //maxHeight: 50.0,
      //maxWidth: 50.0,
    );
    print("You selected camera image : " + cameraFile.path);
    setState(() {});
  }


  //display image selected from camera Ends Here



  //snackBar to prompt user to upload a file Starts Here

  final GlobalKey<ScaffoldState> mScaffoldState = new GlobalKey<ScaffoldState>();

  void noImagePrompt() {
    final snackBar = new SnackBar(content: new Text('No Image Selected!'));
    mScaffoldState.currentState.showSnackBar(snackBar);
  }

  //snackBar to prompt user to upload a file Ends Here


  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      key: mScaffoldState,
      appBar: new AppBar(
        title: new Text('Image Picker'),
      ),
      body: new Container(
        padding: EdgeInsets.all(16.0),
        child: new Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            //displaySelectedFile(galleryFile), //Calling displaySelectedFile
            //displaySelectedFile(cameraFile),
            new RaisedButton(
              child: new Text('Select Image from Gallery'),
              onPressed: imageSelectorGallery,
            ),
            new RaisedButton(
              child: new Text('Select Image from Camera'),
              onPressed: imageSelectorCamera,
            ),

          ],
        ),
      ),
    );
  }


  //Widget to post image and update user profile Starts Here


//  Widget displaySelectedFile(File file) {
//    return Container(
//        child: Column(
//            children: <Widget> [
//              file == null
//                  ? new Text('')
//                  : new Image.file(file, height: 400.0,
//                width: 400.0,),
//              new RaisedButton(
//                elevation: 7.0,
//                textColor: Colors.white,
//                color: Colors.blue,
//                child: new Text('Upload'),
//                onPressed: () async {
//
//                  final FirebaseUser currentUser = await FirebaseAuth.instance.currentUser();
//                  if(currentUser != null && file != null) { //Check if user is not null and user has chosen a file for upload
//
//                    prMyapp = new ProgressDialog(context,ProgressDialogType.Normal);
//
//                    prMyapp.show(); //The loader that shows when a request is being made
//
//                    //Create a reference to the location you want to upload to in Fire base
//                    final StorageReference firebaseStorageRef = FirebaseStorage.instance.ref().child('myimage.jpg');
//
//                    //Upload the file to your Fire base Storage
//                    final StorageUploadTask task = firebaseStorageRef.putFile(file);
//
//                    //Snapshot of the completed task
//                    StorageTaskSnapshot taskSnapshot = await task.onComplete;
//
//                    //Get downloaded url
//                    String downloadUrl = await taskSnapshot.ref.getDownloadURL();
//                    print(downloadUrl);
//
//                    if(downloadUrl != null){
//                      prMyapp.hide(); //Hiding loader after request has been made
//
//                      //Updating user Profile Photo with Downloaded url
//
//                      UserUpdateInfo userUpdateInfo = new UserUpdateInfo();
//                      userUpdateInfo.photoUrl = downloadUrl;
//                      currentUser.updateProfile(userUpdateInfo);
//                      currentUser.reload(); //Running a reload on Users Profile
//
//                      _profilePhotoChanged(); //Calling Updated "Profile Photo" Dialog
//                      print(currentUser);
//
//                    }
//                    else{
//
//                    }
//
//
//                  }
//                  else{
//                    //print("No");
//                    noImagePrompt();
//                  }
//
//
//                },
//              ),
//            ]
//        )
//    );
//  }


//Widget to post image and update user profile Ends Here


  //Alert Dialog for "Invitation Sent Successfully" Start Here

//  Future<void> _profilePhotoChanged() async {
//    return showDialog<void>(
//      context: context,
//      barrierDismissible: false, // user must tap button!
//      builder: (BuildContext context) {
//        return AlertDialog(
//          title: Text('Profile Photo Updated'),
//          content: Text(
//              'Your Profile Photo Has Been Updated Successfully.'),
//          actions: <Widget>[
//            FlatButton(
//              child: Text('Dismiss'),
//              onPressed: () {
//                Navigator.of(context).pop();
//              },
//            ),
//          ],
//        );
//      },
//    );
//  }


//Alert Dialog for "Invitation Sent Successfully" Ends  Here


}
import 'package:flutter/material.dart';
import 'report.dart';
import 'reportmiss.dart';
import 'notifications.dart';
import 'emergency.dart';

class Homeoriginal extends StatefulWidget {

  @override
  _HomeoriginalState createState() => _HomeoriginalState();
}

class _HomeoriginalState extends State<Homeoriginal> {
//  final list_item =[
//    {
//      'name' =
//    }
//
//  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    appBar: new AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: Colors.indigoAccent,
      title: Text("Home Page  "),
    ),
        body: new Container(
        decoration: new BoxDecoration(color: Colors.white),

        padding: EdgeInsets.all(10.0),

        child: GridView.count(
          crossAxisCount: 2,
          children: <Widget>[
          /*  Card(
              margin: EdgeInsets.all(9.0),
              child: InkWell(
                onTap: (){},
                splashColor: Colors.indigoAccent,
                child: Column(
                  mainAxisSize: MainAxisSize.min ,
                  children: <Widget>[
                    Image(
                      width: 95.0,
                      image: AssetImage('assets/group_logo.jpg'),

                    ),
                    new Text('CodeGeeks', style: TextStyle(color: Colors.indigoAccent[800])

                    )],
                ),
              ),
            ),*/

            Card(
              margin: EdgeInsets.all(10.0),
              child: InkWell(
                onTap: ()

                {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (BuildContext context) =>ReportCrime()));
                },
                splashColor: Colors.indigoAccent,
                child: Column(
                  mainAxisSize: MainAxisSize.min ,
                  children: <Widget>[
                    Image(
                      width: 118.0,
                      image: AssetImage('assets/rep.png'),
                    ),
                    new Text('Report Crime', style: TextStyle(color: Colors.indigoAccent[800])

                    )],
                ),
              ),
            ),
          /*  Card(
              margin: EdgeInsets.all(8.0),
              child: InkWell(
                onTap: (){},
                splashColor: Colors.blue,
                child: Column(
                  mainAxisSize: MainAxisSize.min ,
                  children: <Widget>[
                    Image(
                      width: 95.0,
                      image: AssetImage('assets/rep.png'),
                    ),
                    new Text('Report Crime', style: TextStyle(color: Colors.indigoAccent[800])

                    )
                    //Text('Virtual Tour', )
                  ],
                ),
              ),
            ),*/

            Card(
              margin: EdgeInsets.all(10.0),
              child: InkWell(
                onTap: (){},
                splashColor: Colors.indigoAccent,
                child: Column(
                  mainAxisSize: MainAxisSize.min ,
                  children: <Widget>[
                    Image(
                      width: 100.0,
                      image: AssetImage('assets/rep.png'),
                    ),
                    new Text('Report Missing Person', style: TextStyle(color: Colors.indigoAccent[800])

                    )
                  ],
                ),
              ),
            ),

            Card(
              margin: EdgeInsets.all(10.0),
              child: InkWell(
                onTap: (){},
                splashColor: Colors.indigoAccent,
                child: Column(
                  mainAxisSize: MainAxisSize.min ,
                  children: <Widget>[
                    Image(
                      width: 95.0,
                      image: AssetImage('assets/not.png' ),
                    ),
                    new Text('Notifications', style: TextStyle(color: Colors.indigoAccent[800])

                    )
                  ],
                ),
              ),
            ),

            Card(
              margin: EdgeInsets.all(10.0),
              child: InkWell(
                onTap: (){},
                splashColor: Colors.indigoAccent,
                child: Column(
                  mainAxisSize: MainAxisSize.min ,
                  children: <Widget>[
                    Image(
                      image: AssetImage('assets/em.png'),
                    ),
                    new Text('Emergency', style: TextStyle(color: Colors.indigoAccent[800])

                    )
                  ],
                ),
              ),
            ),


          ],

        )
    ));
  }
}



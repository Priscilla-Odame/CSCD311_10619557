import 'package:flutter/material.dart';
import 'LoginPage.dart';

class WTFOUR extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/eme.png'),
              fit: BoxFit.cover
          ) ,
        ),
        //Container(
        margin: EdgeInsets.symmetric(horizontal: 8.0),
        alignment: Alignment.topRight, // top margin
        child: RaisedButton(
            child: Text("Skip", style: TextStyle(
                fontSize: 20
            ),),
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context){
                    return LoginPage();
                  }
                  )
              );
            }

        )
      /*  child: Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.redAccent),
        ),
      ),*/
      // )
    );
  }
}

//Basic Flutter import(s)
import 'package:flutter/material.dart';
import 'dart:async';


class PasswordReset extends StatefulWidget {

  @override
  State<StatefulWidget> createState() => new _PasswordReset();

}

class _PasswordReset extends State<PasswordReset> {

  final formKey = new GlobalKey<FormState>();
  String _email;

  //Initializing ProgressDialog

  //ProgressDialog pr;

  // Check if form is valid before perform login

  bool validateAndSave() {
    final form = formKey.currentState;
    if (form.validate()) {
      form.save();
      return true;
    }
    else {
      return false;
    }

  }


  // Method to Request Forgot password Starts Here


//  void _validateAndSubmit() async {
//
//    pr = new ProgressDialog(context,ProgressDialogType.Normal);
//
//    if (validateAndSave()) {
//      pr = new ProgressDialog(context, ProgressDialogType.Normal);
//
//      try {
//        pr.show(); //The loader that shows when a request is being made
//
//        await FirebaseAuth.instance.sendPasswordResetEmail(email: _email);
//
//        pr.hide(); //Hiding loader after request has been made
//
//        _passwordResetEmailSent();
//      } catch (e) {
//        print(e);
//        if (e.toString().contains("ERROR_NETWORK_REQUEST_FAILED")) { //Poor Connection Error
//          pr.hide(); //Hiding loader after request has been made
//          _nointernet(); //Calling "No internet" Dialog
//        }
//        else if (e.toString().contains("ERROR_USER_NOT_FOUND")) { //User Not Found Error
//          pr.hide(); //Hiding loader after request has been made
//          _noUserFound(); //Calling "User Not Found" Dialog
//        }
//        else {
//          //print("hello");
//        }
//      }
//
//    }
//
//  }


  // Method to Request Forgot password Ends Here


  //Alert Dialog for No User Found Starts Here

//  Future<void> _noUserFound() async {
//    return showDialog<void>(
//      context: context,
//      barrierDismissible: false, // user must tap button!
//      builder: (BuildContext context) {
//        return AlertDialog(
//          title: Text('User Does Not Exist'),
//          content: Text('No User With This Email Was Found.'),
//          actions: <Widget>[
//            FlatButton(
//              child: Text('Dismiss'),
//              onPressed: () {
//                Navigator.of(context).pop();
//              },
//            ),
//          ],
//        );
//      },
//    );
//  }


  //Alert Dialog for No User Found Ends Here


  //Alert Dialog for Password Reset Email Sent Starts Here

//  Future<void> _passwordResetEmailSent() async {
//    return showDialog<void>(
//      context: context,
//      barrierDismissible: false, // user must tap button!
//      builder: (BuildContext context) {
//        return AlertDialog(
//          title: Text('Password Reset'),
//          content: Text('Instructions to Reset Your Password has been sent to Your Email.'),
//          actions: <Widget>[
//            FlatButton(
//              child: Text('Dismiss'),
//              onPressed: () {
//                Navigator.of(context).pop();
//              },
//            ),
//          ],
//        );
//      },
//    );
//  }


  //Alert Dialog for Password Reset Email Sent Ends Here



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.indigoAccent,
        title: Text("Reset Password"),
      ),
      body: new Container(
        decoration: new BoxDecoration(color: Colors.white),
        padding: EdgeInsets.all(16.0),
        child: new Form(
            key: formKey,
            child: new ListView(
              children: <Widget>[
                new FlightImageAsset(),
                new TextFormField(
                  decoration: new InputDecoration(labelText: "Phone Number", icon: new Icon(Icons.phone_in_talk, color: Colors.grey,)),
                  validator: (value) => value.isEmpty ? 'Phone Number is Required' : null,
                  onSaved: (value) => _email = value,
                ),
                SizedBox(height: 20.0),
                new RaisedButton(
                    child: new Text("SUBMIT", style: new TextStyle(fontSize: 20.0),),
                    color: Colors.indigoAccent,
                    elevation: 4.0,
                  onPressed: () {
                    //_validateAndSubmit(); //Calling validateAndSubmit button onpress of SUBMIT button
                  },
                ),
              ],
            )),
      ),
    );
  }

  //Alert Dialog for bad internet connection Starts Here

//  Future<void> _nointernet() async {
//    return showDialog<void>(
//      context: context,
//      barrierDismissible: false, // user must tap button!
//      builder: (BuildContext context) {
//        return AlertDialog(
//          title: Text('Connectivity Lost'),
//          content: Text('Reconnect to the Internet and Try again.'),
//          actions: <Widget>[
//            FlatButton(
//              child: Text('Dismiss'),
//              onPressed: () {
//                Navigator.of(context).pop();
//              },
//            ),
//          ],
//        );
//      },
//    );
//  }

//Alert Dialog for bad internet connection Ends Here



}

//Fire base Image

class FlightImageAsset extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    // var assetsImage = new AssetImage('assets/group_logo.png');
    // var image = new Image(image: assetsImage);
    return new Container(child: Container(
      margin: EdgeInsets.symmetric(horizontal: 20),
      child: Image(
          image: AssetImage("assets/group_logo.png"),
          fit: BoxFit.contain, height: 400),
    )
    );
  }
}
//Flutter Circular Avatar
//https://stackoverflow.com/questions/53513456/flutter-network-image-does-not-fit-in-circular-avatar

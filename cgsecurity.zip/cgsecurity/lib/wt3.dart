import 'package:flutter/material.dart';
import 'wt4.dart';

class WTTHREE extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage('assets/w.t 3.png'),
            fit: BoxFit.cover
        ) ,
      ),
        margin: EdgeInsets.symmetric(horizontal: 8.0),
        alignment: Alignment.topRight, // top margin
        child: RaisedButton(
            child: Text("Skip", style: TextStyle(
                fontSize: 20
            ),),
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context){
                    return WTFOUR();
                  }
                  )
              );
            }

        )
      /*  child: Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.redAccent),
        ),
      ),*/
    );
  }
}

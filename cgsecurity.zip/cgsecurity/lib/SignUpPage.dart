//Basic Flutter import(s)
import 'package:flutter/material.dart';
import 'dart:async';

//LoginPage import(s)
import 'LoginPage.dart';

//FireBase
import 'package:cloud_firestore/cloud_firestore.dart';

//Firebase Authentication
import 'package:firebase_auth/firebase_auth.dart';

//Process Dialog
import 'package:progress_dialog/progress_dialog.dart';



class SignUpPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => new _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {

  final _signUpFormFormKey = new GlobalKey<FormState>();
  String _firstname;
  String _lastname;
  String _phone;
  String _password;
  String smsCode;
  String verificationId;

  //Initializing ProgressDialog

  ProgressDialog pr;

  //Function to validate From

  bool validateAndSave() {
    final signUpForm = _signUpFormFormKey.currentState;
    if (signUpForm.validate()) {
      signUpForm.save();
      return true;
    }
    else {
      return false;
    }

  }

  //Method to sign user up to Starts Here

  void validateAndSubmit() async {

    pr = new ProgressDialog(context,ProgressDialogType.Normal);

    if (validateAndSave()) { //Check if Form is Validated

      try {

        pr.show(); //The loader that shows when a request is being made

        //Signing Up user with Email and Password Starts Here

        FirebaseUser user = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: _phone, password: _password);
        user = await FirebaseAuth.instance.currentUser();
//
//        //End of Signing Up user with Email and Password
//
       if(user != null){
//
//          //After the user Account is created successfully, update Fire base User displayName
//
          UserUpdateInfo userUpdateInfo = new UserUpdateInfo();
          userUpdateInfo.displayName = _firstname;
          user.updateProfile(userUpdateInfo);
          user.reload();
          print(user);

         // pr.hide(); //Hiding loader after request has been made
         // user.sendEmailVerification(); //This is an inbuilt "Fire base" Function called to send "Verification Email" to the User
         // _showVerifyEmailSentDialog(); //Calling "Verify Email" Dialog

        }

      }
      catch (e) {
        print(e);
        if (e.toString().contains("ERROR_NETWORK_REQUEST_FAILED")) { //Check for "Poor Connection" Error
          pr.hide(); //Hiding loader after request has been made
          _nointernet(); //Calling "No internet" Dialog

        }

       // else if(e.toString().contains("ERROR_INVALID_EMAIL")){ //Check for "Invalid Email" Error
         // pr.hide(); //Hiding loader after request has been made
         // _bfemail(); //Calling "Invalid Email" Dialog

        //}
        else if(e.toString().contains("ERROR_WEAK_PASSWORD")){ //Check for "Weak Password" Error
          pr.hide(); //Hiding loader after request has been made
          _weakPassword(); //Calling "Weak Password" Dialog

        }
        else if(e.toString().contains("ERROR_PHONE_ALREADY_IN_USE")){ //Check for "Duplicate User" Error
          pr.hide(); //Hiding loader after request has been made
          _duplicateUser(); //Calling "Email Already in use" Dialog

        }

        else{

        }

      }

    }

  }


  //Method to sign user up to Starts Here



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.indigoAccent,
        title: Text("Sign Up Here"),
      ),
      body: new Container(
        decoration: new BoxDecoration(color: Colors.white),
        padding: EdgeInsets.all(16.0),
        child: new Form(
            key: _signUpFormFormKey,
            child: new ListView(
              //crossAxisAlignment: CrossAxisAlignment.stretch,
              //mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                new FlightImageAsset(),
                new TextFormField(
                  decoration: new InputDecoration(labelText: "First Name", icon: new Icon(Icons.person, color: Colors.grey,)),
                  validator: (value) => value.isEmpty ? 'First Name is Required' : null,
                  onSaved: (value) => _firstname = value,
                ),
                new TextFormField(
                  decoration: new InputDecoration(labelText: "Last Name", icon: new Icon(Icons.person, color: Colors.grey,)),
                  validator: (value) => value.isEmpty ? 'Last Name is Required' : null,
                  onSaved: (value) => _lastname = value,
                ),
                new TextFormField(
                  decoration: new InputDecoration(labelText: "Phone Number", icon: new Icon(Icons.phone_in_talk, color: Colors.grey,)),
                  validator: (value) => value.isEmpty ? 'Phone Number is Required' : null,
                  keyboardType: TextInputType.phone,
                  onSaved: (value) => _phone = value,
                ),
                new TextFormField(
                  decoration: new InputDecoration(labelText: "Password", icon: new Icon(Icons.lock, color: Colors.grey,)),
                  validator: (value) => value.isEmpty ? 'Password is Required' : null,
                  onSaved: (value) => _password = value,
                  obscureText: true,
                ),
                SizedBox(height: 20.0),
                new RaisedButton(
                    child: new Text("SignUp", style: new TextStyle(fontSize: 20.0),
                    ),
                    color: Colors.indigoAccent,
                    elevation: 4.0,
                    onPressed: () {
                      //validateAndSubmit(); //Calling validateAndSubmit button onpress of SignUp button
                    }),
                FlatButton(
                  child: Text('Have an account? Login'),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()),
                    );
                  },
                ),
              ],
            )),
      ),
    );
  }


  //Dialog Boxes Starts Here


  //Alert Dialog for badly formatted Email Starts Here

//  Future<void> _bfemail() async {
//    return showDialog<void>(
//      context: context,
//      barrierDismissible: false, // user must tap button!
//      builder: (BuildContext context) {
//        return AlertDialog(
//          title: Text('Email is Invalid'),
//          content: Text('The Email Address is Badly Formatted'),
//          actions: <Widget>[
//            FlatButton(
//              child: Text('Retry'),
//              onPressed: () {
//                Navigator.of(context).pop();
//              },
//            ),
//          ],
//        );
//      },
//    );
//  }


//Alert Dialog for badly formatted Email Ends Here



 // Alert Dialog for weak Password Starts Here

  Future<void> _weakPassword() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Passwords is too short'),
          content: Text('The password must be 6 characters long or more.'),
          actions: <Widget>[
            FlatButton(
              child: Text('Retry'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }


//Alert Dialog for weak Password Ends Here


  //Alert Dialog for Duplicate User Starts Here

  Future<void> _duplicateUser() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Number Already In Use'),
          content: Text('The Phone Number You Provided Is Already In Use.'),
          actions: <Widget>[
            FlatButton(
              child: Text('Dismiss'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }


//Alert Dialog for Duplicate User Ends Here


  //Alert Dialog for "Poor Internet Connection" Starts Here

  Future<void> _nointernet() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Connectivity Lost'),
          content: Text('Reconnect to the Internet and Try again.'),
          actions: <Widget>[
            FlatButton(
              child: Text('Dismiss'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }


//Alert Dialog for "Poor Internet Connection" Ends Here


  //Alert Dialog for Verify Email Starts Here

//  void _showVerifyEmailSentDialog() {
//    showDialog(
//      context: context,
//      builder: (BuildContext context) {
//        // return object of type Dialog
//        return AlertDialog(
//          title: new Text("Verify your account"),
//          content: new Text("Link to verify account has been sent to your email"),
//          actions: <Widget>[
//            new FlatButton(
//              child: new Text("Dismiss"),
//              onPressed: () {
//                _signUpFormFormKey.currentState.reset(); //Clearing Data in the From
//                Navigator.of(context).pop();
//              },
//            ),
//          ],
//        );
//      },
//    );
 /* (AuthCredential phoneAuthCredential) {
//  }

 / void _verifyPhoneNumber() async {
    setState(() {
      _message = '';
    });
    final PhoneVerificationCompleted verificationCompleted =
      _auth.signInWithCredential(phoneAuthCredential);
      setState(() {
        _message = 'Received phone auth credential: $phoneAuthCredential';
      });
    };

    final PhoneVerificationFailed verificationFailed =
        (AuthException authException) {
      setState(() {
        _message =
        'Phone number verification failed. Code: ${authException.code}. Message: ${authException.message}';
      });
    };

    final PhoneCodeSent codeSent =
        (String verificationId, [int forceResendingToken]) async {
      widget._scaffold.showSnackBar(SnackBar(
        content:
        const Text('Please check your phone for the verification code.'),
      ));
      _verificationId = verificationId;
    };

    final PhoneCodeAutoRetrievalTimeout codeAutoRetrievalTimeout =
        (String verificationId) {
      _verificationId = verificationId;
    };

    await _auth.verifyPhoneNumber(
        phoneNumber: _phoneNumberController.text,
        timeout: const Duration(seconds: 5),
        verificationCompleted: verificationCompleted,
        verificationFailed: verificationFailed,
        codeSent: codeSent,
        codeAutoRetrievalTimeout: codeAutoRetrievalTimeout);
  }

  // Example code of how to sign in with phone.
  void _signInWithPhoneNumber() async {
    final AuthCredential credential = PhoneAuthProvider.getCredential(
      verificationId: _verificationId,
      smsCode: _smsController.text,
    );
    final FirebaseUser user = await _auth.signInWithCredential(credential);
    final FirebaseUser currentUser = await _auth.currentUser();
    assert(user.uid == currentUser.uid);
    setState(() {
      if (user != null) {
        _message = 'Successfully signed in, uid: ' + user.uid;
      } else {
        _message = 'Sign in failed';
      }
    });
  }
}
*/

//Alert Dialog for Verify Email Ends Here


  //End of Dialog Boxes

  }

//Fire_base Image

class FlightImageAsset extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //var assetsImage = new AssetImage('images/group_logo.png');
   // var image = new Image(image: assetsImage);
    return new Container(child: Container(
    margin: EdgeInsets.symmetric(vertical: 20),
    child: Image(
    image: AssetImage("assets/group_logo.png"),
    fit: BoxFit.contain, height: 400),
    )
    );
  }

}

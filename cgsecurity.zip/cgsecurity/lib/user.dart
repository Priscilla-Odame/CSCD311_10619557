//import 'package:cloud_firestore/cloud_firestore.dart';

//class UserDetails{
//  getUser(String uid) {
//    return Firestore.instance
//        .collection('user')
//        .where('uid', isEqualTo: uid)
//        .getDocuments();
//  }
//}
//
////Check Invites Table
//
//class checkInvites{
//  getUser(String uid) {
//    return Firestore.instance
//        .collection('invites')
//        .where('uid', isEqualTo: uid)
//        .getDocuments();
//  }
//}
//
////Update Profile Image
//
//class UpdateProfileImage{
//  getUser(String uid) {
//    return Firestore.instance
//        .collection('users')
//        .where('uid', isEqualTo: uid)
//        .getDocuments();
//  }
//}
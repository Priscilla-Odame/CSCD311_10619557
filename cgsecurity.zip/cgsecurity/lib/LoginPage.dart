//Basic Flutter import(s)
import 'homepage.dart';
import 'package:flutter/material.dart';
import 'dart:async';

//RequestInvitation Page import(s)
import 'requestInvitation.dart';

//SignUpPage import(s)
import 'SignUpPage.dart';

//PasswordReset Page import(s)
import 'passwordReset.dart';

//FireBase
import 'package:cloud_firestore/cloud_firestore.dart';

//Firebase Authentication
import 'package:firebase_auth/firebase_auth.dart';

//Process Dialog
import 'package:progress_dialog/progress_dialog.dart';

//Shared Peferences
import 'package:shared_preferences/shared_preferences.dart';


class LoginPage extends StatefulWidget {
  //LoginPage({Key key, this.auth}) : super(key: key);

  //final BaseAuth auth;

  @override
  State<StatefulWidget> createState() => new _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  final _loginFormKey = new GlobalKey<FormState>();
  String _phone;
  String _password;

//  //Initializing ProgressDialog
//
  ProgressDialog pr;


  // Check if Form is Valid Before Performing Login

  bool validateAndSave() {
    final form = _loginFormKey.currentState;
    if (form.validate()) {
      form.save();
      return true;
    }
    else {
      return false;
    }

  }

  // Method to check if Form is validated Starts Here

  void validateAndSubmit() async {
    if (validateAndSave()) {
      try {
        _checkEmailVerification();
      }
      catch (e) {
        print(e);
      }
    }

  }


  // Method to check if Form is validated Ends Here



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.indigoAccent,
        title: Text("Login Here"),
      ),
      body: new Container(
        decoration: new BoxDecoration(color: Colors.white),
        padding: EdgeInsets.all(16.0),
        child: new Form(
            key: _loginFormKey,
            child: new ListView(
              children: <Widget>[
                new FlightImageAsset(),
                new TextFormField(
                  decoration: new InputDecoration(labelText: "Phone Number", icon: new Icon(Icons.phone_in_talk, color: Colors.grey,)),
                  validator: (value) => value.isEmpty ? 'Phone number is required' : null,
                  onSaved: (value) => _phone = value,
                ),
                new TextFormField(
                  decoration: new InputDecoration(labelText: 'Password', icon: new Icon(Icons.lock, color: Colors.grey,)),
                  validator: (value) => value.isEmpty ? 'Password is Required' : null,
                  onSaved: (value) => _password = value,
                  obscureText: true,
                ),
                SizedBox(height: 20.0),
                new RaisedButton(
                    child: new Text("Login", style: new TextStyle(fontSize: 20.0),),
                    color: Colors.indigoAccent,
                    elevation: 4.0,
                    onPressed: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context){
                            return Homeoriginal();
                          }
                          )
                      );
                      //validateAndSubmit ();
                    }
                ),
                FlatButton(
                  child: Text('Forgot Password?'),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => PasswordReset()),
                    );
                  },
                ),
                FlatButton(
                  child: Text('New?Click here to Register'),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SignUpPage()),
                    );
                  },
                ),
              ],
            )),
      ),
    );

  }


  //Method to Log User in Starts Here

  void _checkEmailVerification() async {

    pr = new ProgressDialog(context,ProgressDialogType.Normal);

    try {

      pr.show(); //The loader that shows when a request is being made

      //Logging in user with Email and Password Starts Here

      FirebaseUser user = await FirebaseAuth.instance.signInWithEmailAndPassword(email: _phone, password: _password);
      user = await FirebaseAuth.instance.currentUser();
      print(user);

      //Logging in user with Email and Password Ends Here

      if(user != null) {

        if (user.toString().contains("isEmailVerified: false")) { //Check if user has Verified Account
          pr.hide(); //Hiding loader after request has been made
          _showVerifyEmailDialog(); //Calling "Verify Email" Dialog
        }

        else {
          //assert(userConfirmed != null);
          //assert(await userConfirmed.getIdToken() != null);

          final FirebaseUser currentUser = await FirebaseAuth.instance.currentUser();
          assert(user.uid == currentUser.uid);

          Firestore.instance.collection('users').document().setData({ //Create a "user" table
            'uid': user.uid, //Adding "uid" to user table
            'email': user.phoneNumber, //Adding "email" to user table
            'username': user.displayName, //Adding "username" to user table
            'isEmailVerified': user.isEmailVerified, //Adding "isEmailVerified" to user table
          });

          SharedPreferences prefs = await SharedPreferences.getInstance();
          prefs.setString('sp_user_uid', currentUser.uid);
          prefs.setString('sp_username', currentUser.displayName);

          Navigator.push(context, MaterialPageRoute(builder: (context) => RequestInvitationPage()));
        }

      }

    }catch(e){
      print(e);
      if (e.toString().contains("ERROR_NETWORK_REQUEST_FAILED")) { //Poor Connection Error
        pr.hide(); //Hiding loader after request has been made
        _nointernet(); //Calling "No internet" Dialog

      }
      else if (e.toString().contains("ERROR_USER_NOT_FOUND")) { //User Not Found Error
        pr.hide(); //Hiding loader after request has been made
        _noUserFound(); //Calling "User Not Found" Dialog

      }
      else{


      }

    }

  }


//Method to Log User in Ends Here


  //Function to resend "Verification Email" Starts Here

  void _resentVerifyEmail() async{
    FirebaseUser user = await FirebaseAuth.instance.currentUser();
    user.sendEmailVerification();
    _showVerifyEmailSentDialog();
  }


//Function to resend "Verification Email" Starts Here


  //Dialog Boxes Starts Here

  //Alert Dialog for "Verification Email" Starts Here

  void _showVerifyEmailSentDialog() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text("Verify Your Account"),
          content: new Text("Link to verify account has been sent to your email"),
          actions: <Widget>[
            new FlatButton(
              child: new Text("Resend Link"),
              onPressed: () async {
                FirebaseUser user = await FirebaseAuth.instance.currentUser();
                Navigator.of(context).pop();
                pr.show();
                user.sendEmailVerification();
                pr.hide();
                _showVerifyEmailSentDialog();
              },
            ),
            new FlatButton(
              child: new Text("Dismiss"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }



//Alert Dialog for "Verification Email" Ends Here


  //Alert Dialog for "Poor Internet Connection" Starts Here

  Future<void> _nointernet() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Connectivity Lost'),
          content: Text('Reconnect to the Internet and Try again.'),
          actions: <Widget>[
            FlatButton(
              child: Text('Dismiss'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }


//Alert Dialog for "Poor Internet Connection" Ends Here



  //Alert Dialog for "No User Found" Starts Here

  Future<void> _noUserFound() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('User Does Not Exist'),
          content: Text(
              'No User With This Email Was Found.'),
          actions: <Widget>[
            FlatButton(
              child: Text('Dismiss'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }


//Alert Dialog for "No User Found" Starts Here


  //Alert Dialog for "Verify Email" Starts Here

  Future<void> _showVerifyEmailDialog() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text("Verify your account"),
          content: new Text("Please verify account in the link sent to email"),
          actions: <Widget>[
            new FlatButton(
              child: new Text("Resend link"),
              onPressed: () {
                Navigator.of(context).pop();
                _resentVerifyEmail();
              },
            ),
            new FlatButton(
              child: new Text("Dismiss"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }


//Alert Dialog for "Verify Email" Starts Here


  //Dialog Boxes Ends Here

}

//Fire_base Image

class FlightImageAsset extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
   // var assetsImage = new AssetImage('assets/group_logo.png');
   // var image = new Image(image: assetsImage);
    return new Container(child: Container(
      margin: EdgeInsets.symmetric(vertical: 20),
      child: Image(
          image: AssetImage("assets/group_logo.png"),
          fit: BoxFit.contain, height: 400),
    )

    );
  }

}


//Flutter Circular Avatar
//https://stackoverflow.com/questions/53513456/flutter-network-image-does-not-fit-in-circular-avatar

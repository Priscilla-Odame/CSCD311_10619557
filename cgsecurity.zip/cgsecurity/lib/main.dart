import 'package:flutter/material.dart';
import 'dart:async';
import 'wt2.dart';
/*import 'requestInvitation.dart';
import 'SignUpPage.dart';
import 'LoginPage.dart';*/

/*void main() => runApp(MyApp());


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Firebase SetUp",
      theme: new ThemeData(
        primarySwatch: Colors.orange,
      ),
      //home: new SubmitPage()
        home: new LoginPage()
    );
  }
}*/
void main()   {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: SplashScreen(),
  ));
}

class SplashScreen extends StatefulWidget {

  @override
  State<StatefulWidget> createState() {
    return SplashScreenState();
  }
}

class SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();

    loadData();
  }

  Future<Timer> loadData() async {
    return new Timer(Duration(seconds: 5), onDoneLoading);
  }

  onDoneLoading() async {
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => HomeScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage('assets/group_logo.png'),
            fit: BoxFit.cover
        ) ,
      ),
      /*  child: Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.redAccent),
        ),
      ),*/
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage('assets/w.t 1.png'),
            fit: BoxFit.cover
        ) ,
      ),
        margin: EdgeInsets.symmetric(horizontal: 8.0),
        alignment: Alignment.topRight,// top margin
        child: RaisedButton(
            child: Text("Skip", style: TextStyle(
                fontSize: 20
            ),),
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context){
                    return WTTWO();
                  }
                  )
              );
            }

        )
      /*  child: Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.redAccent),
        ),
      ),*/
    );
  }
}